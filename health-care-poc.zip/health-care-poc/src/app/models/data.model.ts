export interface Data {
    State: string;
    MeasurePerformanceRate: number;
}
